<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Complaint extends Model
{
    use HasFactory;
    protected $guarded = [];

    public const ROOT_CAUSES = [
        'Power issues',
        'Static IP issues',
        'Low bandwidth issues',
        'LED issues',
        'Short Circuit/Burnt issues',
        'Thunder storms',
        'Water logging',
        'Monkey Menace',
        'Others',
    ];

    public function user(){
        return $this->belongsTo(User::class,'user_id','id');
    }


    public function item(){
        return $this->belongsTo(items::class,'item_id','id');
    }
    
    public function category(){
        return $this->belongsTo(Category::class,'cat_id','id');
    }

    public function region()
    {
        return $this->user->belongsTo(Region::class,'region_id','id');
    }

    public function raisedBy()
    {
        return $this->belongsTo(User::class, 'raised_by');
    }

    public function statusUpdates()
    {
        return $this->hasMany(Comment::class, 'complaint_id', 'id')
            ->orderBy('created_at');
    }

    public function uploadedFiles()
    {
        return $this->hasMany(ComplaintImage::class, 'complaint_id', 'id')
            ->orderBy('created_at');
    }
}
