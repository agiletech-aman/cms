<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RoleController extends Controller
{
    public function AllPermission()
    {
        $permissions = Permission::all();

        return view('admin.permission.all_permission', compact('permissions'));
    } //End Method

    public function AddPermission()
    {

        return view('admin.permission.add_permission');
    } //End Method

    public function StorePermission(Request $request)
    {
        $role = Permission::create([
            'name' => $request->name,
            'group_name' => $request->group_name,
        ]);

        $notification = array(
            'message' => 'Permission Inserted Successfully',
            'alert-type' => 'success'
        );

        return redirect()->route('all.permission')->with($notification);
    } //End Method

    public function EditPermission($id)
    {
        $permission = Permission::findOrFail($id);
        return view('admin.permission.edit_permission', compact('permission'));
    } // End Method


    public function UpdatePermission(Request $request)
    {
        $per_id = $request->id;
        Permission::findOrFail($per_id)->update([
            'name' => $request->name,
            'group_name' => $request->group_name,
        ]);

        $notification = array(
            'message' => 'Permission Updated Successfully',
            'alert-type' => 'success'
        );

        return redirect()->route('all.permission')->with($notification);
    } //End Method

    public function DeletePermission($id)
    {
        Permission::findOrFail($id)->delete();

        $notification = array(
            'message' => 'Permission Deleted Successfully',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    } //End Method


    //ALl Roles Method

    public function AllRoles()
    {
        $roles = Role::all();

        return view('admin.roles.all_roles', compact('roles'));
    } //End Method

    public function AddRoles()
    {

        return view('admin.roles.add_roles');
    } //End Method


    public function StoreRoles(Request $request)
    {
        $role = Role::create([
            'name' => $request->name,

        ]);

        $notification = array(
            'message' => 'Role Inserted Successfully',
            'alert-type' => 'success'
        );

        return redirect()->route('all.roles')->with($notification);
    } //End Method

    public function EditRoles($id)
    {
        $role = Role::findOrFail($id);
        return view('admin.roles.edit_roles', compact('role'));
    } // End Method


    public function UpdateRoles(Request $request)
    {
        $role_id = $request->id;
        Role::findOrFail($role_id)->update([
            'name' => $request->name,
        ]);

        $notification = array(
            'message' => 'Role Updated Successfully',
            'alert-type' => 'success'
        );

        return redirect()->route('all.roles')->with($notification);
    } //End Method

    public function DeleteRoles($id)
    {
        Role::findOrFail($id)->delete();

        $notification = array(
            'message' => 'Role Deleted Successfully',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    } //End Method

    ///////////////// ADD ROle for Permission /////////////////

    public function AddRolesPermission()
    {

        $roles = Role::all();
        $permission = Permission::all();
        $permission_groups = User::getpermissionGroups();

        return view('admin.roles.add_roles_permission', compact('roles', 'permission', 'permission_groups'));
    } //End Method

    public function RolePermissionStore(Request $request)
    {

        $data = array();
        $permissions = $request->permission;

        foreach ($permissions as $key => $item) {
            $data['role_id'] = $request->role_id;
            $data['permission_id'] = $item;

            DB::table('role_has_permissions')->insert($data);
        }
        $notification = array(
            'message' => 'Role Permission Added Successfully',
            'alert-type' => 'success'
        );

        return redirect()->route('all.roles.permission')->with($notification);
    } //End Method

    public function AllRolesPermission()
    {
        $roles = Role::all();
        return view('admin.roles.all_roles_permission', compact('roles'));
    } //End Method


    public function AdminEditRoles($id)
    {

        $role = Role::findOrFail($id);
        $permissions = Permission::all();
        $permission_groups = User::getpermissionGroups();

        return view('admin.roles.edit_roles_permission', compact('role', 'permissions', 'permission_groups'));
    } // End Method

    public function RolePermissionUpdate(Request $request, $id)
    {

        $role = Role::findOrFail($id);
        $permissions = $request->permission;


        $numericPermissionArray = [];
        foreach ($permissions as $permission) {
            $numericPermissionArray[] = intval($permission);
        }

        if (!empty($numericPermissionArray)) {
            $role->syncPermissions($numericPermissionArray);
        }

        $notification = array(
            'message' => 'Role Permission Updated Successfully',
            'alert-type' => 'success'
        );

        return redirect()->route('all.roles.permission')->with($notification);
    } // End Method

    public function AdminDeleteRoles($id)
    {
        $role = Role::findOrFail($id);
        if (!is_null($role)) {
            $role->delete();
        }
        $notification = array(
            'message' => 'Role Permission Deleted Successfully',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    } // End Method




}
