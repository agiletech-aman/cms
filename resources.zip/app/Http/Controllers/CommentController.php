<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\ComplaintImage;
use App\Models\IncidentComment;
use App\Models\OldComment;
use App\Models\User;
use App\Notifications\CommentNotification;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Notification;

class CommentController extends Controller
{
    public function StoreComment(Request $request, $id)
    {

        $users = User::role('SuperAdmin')->get();

        $request->validate([
            'comment' => 'required',
            'comment_files' => 'nullable|array',
            'comment_files.*' => 'file|mimes:jpeg,png,jpg,gif,svg,pdf|max:2048',
        ], [
            'comment_files.*.mimes' => 'Only jpeg, png, jpg, gif, svg, and pdf formats are allowed.',
            'comment_files.*.max' => 'Each file must not exceed 2MB.',
        ]);

        $user = User::find(Auth::id());
        $comment = Comment::create([
            'complaint_id' => $id,
            'comment' => $request->comment,
            'user_id' => $user->id,
            'created_at' => Carbon::now(),
        ]);

        if ($request->hasFile('comment_files')) {
            foreach ($request->file('comment_files') as $file) {
                $name_gen = hexdec(uniqid()) . '.' . strtolower($file->getClientOriginalExtension());
                $file->move(public_path('upload/complaint_files'), $name_gen);

                ComplaintImage::create([
                    'complaint_id' => $id,
                    'user_id' => $user->id,
                    'complaint_image' => 'upload/complaint_files/' . $name_gen,
                    'comment_id' => $comment->id,
                    'created_at' => Carbon::now(),
                ]);
            }
        }

        Notification::send($users, new CommentNotification($request->only('comment')));

        $notification = array(
            'message' => 'Comment Added Successfully',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    } //End Method

    public function StoreOldComment(Request $request, $id)
    {

        $users = User::role('SuperAdmin')->get();

        $request->validate([
            'comment' => 'required',
        ]);

        $user = User::find(Auth::id());
        OldComment::insert([
            'complaint_id' => $id,
            'comment' => $request->comment,
            'user_id' => $user->id,
            'created_at' => Carbon::now(),
        ]);

        Notification::send($users, new CommentNotification($request));

        $notification = array(
            'message' => 'Comment Added Successfully',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    } //End Method

    public function StoreIncidentComment(Request $request, $id)
    {

        $users = User::role('SuperAdmin')->get();

        $request->validate([
            'comment' => 'required',
        ]);

        $user = User::find(Auth::id());
        IncidentComment::insert([
            'incident_id' => $id,
            'comment' => $request->comment,
            'user_id' => $user->id,
            'created_at' => Carbon::now(),
        ]);

        Notification::send($users, new CommentNotification($request));

        $notification = array(
            'message' => 'Comment Added Successfully',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    } //End Method
}
